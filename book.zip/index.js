const express = require('express');
const http = require('http');
const path = require('path');
const dotenv = require('dotenv');
const sequelize = require('./config/database');
const libraryRoutes = require('./routes/library');
const userRoutes = require('./routes/users'); // Ensure this path is correct

dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Routes
app.use('/api', libraryRoutes);
app.use('/api', userRoutes); // Include user routes under /api

// Serve static files (if applicable)
app.use(express.static(path.join(__dirname, 'public')));

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something went wrong!');
});

// Database synchronization
sequelize.sync()
    .then(() => {
        console.log('Database synchronized');
        // Start the server
        server.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}/`);
        });
    })
    .catch(err => {
        console.error('Unable to connect to the database:', err);
    });
