const express = require('express');
const router = express.Router();
const Library = require('../models/library');

// GET all books in the library
router.get('/library', async (req, res) => {
    try {
        const books = await Library.findAll();
        res.json(books);
    } catch (err) {
        console.error('Error retrieving books:', err);
        res.status(500).json({ message: 'Error retrieving books' });
    }
});

// POST a new book to the library
router.post('/library', async (req, res) => {
    const { bookname, publisher, author, url } = req.body;
    try {
        const newBook = await Library.create({
            bookname,
            publisher,
            author,
            url
        });
        res.status(201).json(newBook);
    } catch (err) {
        console.error('Error creating book:', err);
        res.status(500).json({ message: 'Error creating book' });
    }
});

// PUT update a book in the library
router.put('/library/:id', async (req, res) => {
    const { id } = req.params;
    const { bookname, publisher, author, url } = req.body;
    try {
        const book = await Library.findByPk(id);
        if (!book) {
            return res.status(404).json({ message: 'Book not found' });
        }
        await book.update({
            bookname,
            publisher,
            author,
            url
        });
        res.json(book);
    } catch (err) {
        console.error('Error updating book:', err);
        res.status(500).json({ message: 'Error updating book' });
    }
});

// DELETE a book from the library
router.delete('/library/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const book = await Library.findByPk(id);
        if (!book) {
            return res.status(404).json({ message: 'Book not found' });
        }
        await book.destroy();
        res.json({ message: 'Book deleted successfully' });
    } catch (err) {
        console.error('Error deleting book:', err);
        res.status(500).json({ message: 'Error deleting book' });
    }
});

module.exports = router;
