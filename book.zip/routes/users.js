const express = require('express');
const router = express.Router();
const User = require('../models/user');

// POST a new user
router.post('/users', async (req, res) => {
  const {
    fullName,
    email,
    password,
    phoneNumber,
    gender,
    dateOfBirth,
    state,
    city,
    classEntry,
    firstChoiceSainikSchool
  } = req.body;

  try {
    const newUser = await User.create({
      fullName,
      email,
      password,
      phoneNumber,
      gender,
      dateOfBirth,
      state,
      city,
      classEntry,
      firstChoiceSainikSchool,
    });

    res.status(201).json(newUser);
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ message: 'Error creating user' });
  }
});

// POST login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const isValidPassword = await user.comparePassword(password);

    if (!isValidPassword) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        phoneNumber: user.phoneNumber,
        gender: user.gender,
        dateOfBirth: user.dateOfBirth,
        state: user.state,
        city: user.city,
        classEntry: user.classEntry,
        firstChoiceSainikSchool: user.firstChoiceSainikSchool
      }
    });
  } catch (err) {
    console.error('Error during login:', err);
    res.status(500).json({ success: false, message: 'Error during login', error: err.message });
  }
});

// GET all users
router.get('/users', async (req, res) => {
  try {
    const users = await User.findAll();

    if (!users || users.length === 0) {
      return res.status(404).json({ message: 'No users found' });
    }

    res.json(users); // Return all users as JSON array
  } catch (err) {
    console.error('Error retrieving users:', err);
    res.status(500).json({ message: 'Error retrieving users', error: err.message });
  }
});

module.exports = router;
